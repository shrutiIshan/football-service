package com.football.match.footballstandingsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballStandingsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballStandingsServiceApplication.class, args);
	}

}
