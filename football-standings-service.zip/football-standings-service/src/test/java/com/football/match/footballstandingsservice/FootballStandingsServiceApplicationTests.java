package com.football.match.footballstandingsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballStandingsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
